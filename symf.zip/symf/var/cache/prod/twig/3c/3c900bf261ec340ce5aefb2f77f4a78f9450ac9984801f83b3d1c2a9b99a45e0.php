<?php

/* blog/index.html.twig */
class __TwigTemplate_a77939f5a5f2d913e5b5f9c166cc4a2d60219a2e22044c9661e91038f095f17c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "blog/index.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        echo "blog_index";
    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        // line 6
        echo "<div><strong>TODO #2</strong>: Ajouter aux Posts un champ de type texte pour représenter une catégorie, et pouvoir le gérer dans l'admin.</div>
<div><strong>TODO #4</strong>: Ne pas afficher dans cette liste les posts dont le titre contient \"Lorem ipsum\", peu importe la casse.</div>

   
    

    ";
        // line 12
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["posts"]) ? $context["posts"] : null));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["post"]) {
            // line 13
            echo "
    ";
            // line 14
            $context["onsearch"] = twig_lower_filter($this->env, $this->getAttribute($context["post"], "title", array()));
            // line 15
            echo "
    ";
            // line 16
            if (!twig_in_filter("lorem", (isset($context["onsearch"]) ? $context["onsearch"] : null))) {
                // line 17
                echo "     
        <article class=\"post\">
            <h2>
                <a href=\"";
                // line 20
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_post", array("slug" => $this->getAttribute($context["post"], "slug", array()))), "html", null, true);
                echo "\">
                    ";
                // line 21
                echo twig_escape_filter($this->env, $this->getAttribute($context["post"], "title", array()), "html", null, true);
                echo "
                </a>
            </h2>
            <div>
                <strong>TODO #1</strong>: Afficher ici la date publishedAt existante ";
                // line 25
                if ($this->getAttribute($context["post"], "publishedAt", array())) {
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["post"], "publishedAt", array()), "Y-m-d H:i"), "html", null, true);
                }
                // line 26
                echo "            </div>
            <div>
                <strong>TODO #3</strong>: ";
                // line 28
                echo twig_escape_filter($this->env, $this->getAttribute($context["post"], "category", array()), "html", null, true);
                echo "
            </div>
            ";
                // line 30
                echo $this->env->getExtension('AppBundle\Twig\AppExtension')->markdownToHtml($this->getAttribute($context["post"], "summary", array()));
                echo "
        </article>
        ";
            }
            // line 33
            echo "    ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 34
            echo "        <div class=\"well\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("post.no_posts_found"), "html", null, true);
            echo "</div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['post'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 36
        echo "
    ";
        // line 37
        if ($this->getAttribute((isset($context["posts"]) ? $context["posts"] : null), "haveToPaginate", array())) {
            // line 38
            echo "        <div class=\"navigation text-center\">
            ";
            // line 39
            echo $this->env->getExtension('WhiteOctober\PagerfantaBundle\Twig\PagerfantaExtension')->renderPagerfanta((isset($context["posts"]) ? $context["posts"] : null), "twitter_bootstrap3_translated", array("routeName" => "blog_index_paginated"));
            echo "
        </div>
    ";
        }
    }

    // line 44
    public function block_sidebar($context, array $blocks = array())
    {
        // line 45
        echo "    ";
        $this->displayParentBlock("sidebar", $context, $blocks);
        echo "

    ";
        // line 47
        echo $this->env->getExtension('CodeExplorerBundle\Twig\SourceCodeExtension')->showSourceCode($this->env, $this);
        echo "
    ";
        // line 48
        echo twig_include($this->env, $context, "blog/_rss.html.twig");
        echo "
";
    }

    public function getTemplateName()
    {
        return "blog/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  140 => 48,  136 => 47,  130 => 45,  127 => 44,  119 => 39,  116 => 38,  114 => 37,  111 => 36,  102 => 34,  97 => 33,  91 => 30,  86 => 28,  82 => 26,  78 => 25,  71 => 21,  67 => 20,  62 => 17,  60 => 16,  57 => 15,  55 => 14,  52 => 13,  47 => 12,  39 => 6,  36 => 5,  30 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "blog/index.html.twig", "D:\\xampp\\htdocs\\work\\symf\\app\\Resources\\views\\blog\\index.html.twig");
    }
}
